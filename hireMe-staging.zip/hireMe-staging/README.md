# HireMe

## Development Settings

```BASH
python3 -m venv virtual
source ./virtual/bin/activate
cd hireMe/
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```
