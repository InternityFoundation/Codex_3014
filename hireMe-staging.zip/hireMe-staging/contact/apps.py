from django.apps import AppConfig


class ContactConfig(AppConfig):
    name = 'contact'
