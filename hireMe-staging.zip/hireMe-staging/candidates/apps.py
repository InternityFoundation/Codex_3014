from django.apps import AppConfig


class CandidatesConfig(AppConfig):
    name = 'candidates'
